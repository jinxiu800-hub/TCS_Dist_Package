---
name: tcs-prompt-templates
description: Trading Cognitive System (TCS) standard report templates across four differential perspectives.
version: 3.0.0
---

# TCS Report Template Library (TCS 报告模板库)

本库定义了 TCS 在物理存档阶段必须严格执行的四维度输出规格。严禁混淆语言、合并视图或在模板外添加 AI 助手对话。

## 🛠️ 核心交付物规格 (The 4+1 Rule)

### 📄 模板 1: `report_machine.md`
- **Target**: Machine-Level Logic View (纯机器解析视图)
- **Language**: **Strictly English Only**
- **Constraint**: 仅限 JSON 结构、布尔矩阵和定量数值。禁止任何自然语言描述。
- **Template**:
```markdown
# [TCS-Machine] {Tf} {Session} Chart Analysis
## 1. SYSTEM_METADATA
- TIMESTAMP: [YYYY-MM-DD HH:mm:ss]
- SESSION_ID: [Session ID]
- TARGET_NODE: [Node ID]

## 2. QUANTIFIED_VISUAL_FACTS
- V_1: [Price Delta / MA Angle / Vector value]
- V_2: [ATR Value / Overlap %]
- V_ la: [Bar Index / Coordinate]

## 3. BOOLEAN_MATRIX
- [Slot_Name_1] = TRUE/FALSE <- [Fact Check Evidence]
- [Slot_Name_2] = TRUE/FALSE <- [Fact Check Evidence]
- TR_STATE_SWITCH = TRUE/FALSE (Active if $\ge 5$ bars)

## 4. DETERMINISTIC_PROBABILITY_MATRIX
```json
{
  "session_id": "XXXX",
  "node_id": "XXXX",
  "setup": "XXXX",
  "quality_score": "N/5",
  "prob": 0.XX,
  "execution": {
    "entry": XX.XX,
    "target": XX.XX,
    "stop_loss": XX.XX
  }
}
```
```
```

#### 📄 模板 2: `report_human.md`
- **Target**: 专业交易员视图 (Professional Trader Audit)
- **Language**: **专业中文 (保留 PA 英文术语)**
- **Constraint**: 必须执行 L-Chain 推导，严禁模糊词汇，必须包含 Quality Check 评分。
- **Template**:
```markdown
# [TCS-Execution] {Tf} {Session} 图表分析
## 1. 架构调度与状态感知
- **[时段调度]**: [时段名称] $\rightarrow$ [任务节点1] $\rightarrow$ [任务节点2]
- **[状态分析]**: [标准 PA 术语，如: Strong Bear Trend / Tight Channel / Trading Range]

## 2. 市场行为 
- **结构锚点**: [关键价格转折、极值、或关键 Bar 编号、或者目前形态]
- **EMA 关系**: $\Delta \text{Price} = \text{X}$，价格与 EMA20 交互状态 $\rightarrow$ [支撑 / 穿透 / 纠缠]
- **40-60 法则**: [阐述价格对支撑/阻力区间的突破/回撤力度]
- **[Quality Check]**: Body(X) + Close(Y) + Size(Z) = Total Score: N/5
- **[Audit Mode]**: [Mode A: Pivot Zone 3-5 Bars / Mode B: 3-Segment Rolling Audit]

## 3. 意图匹配与逻辑路径
- **[交易意图]**: [Swing 或 Scalp] $\rightarrow$ 适配当前波动率环境
- **[逻辑路径]**: invest_db.json $\rightarrow$ [判定节点 ID] (T/F) $\rightarrow$ [最终结论]

## 4. 交易执行参数 [关键参数]
- **入场点**: [精确信号 K 线或突破触发点位]
- **止损点**: [极值点之外的逻辑位置]
- **目标位**: [基于结构顶/底或 Measured Move 测算]

## 5. 风控与判定 [风控提醒]
- ⚠️ [当前趋势斜率特征与结构风险提示]
- **延续/反转**: [未来行情在目标位处的微观 K 线条件/确认逻辑]

```
---

### 📄 模板 3: `report_generic.md`
- **Target**: 通用风控/管理视图 (Middle Office & Risk Management View)
- **Language**: **完全中文 (面向风险审计)(行为金融学叙事)**
- **Constraint**: 聚焦逻辑完整性、风控边界与数学期望。
- **Template**:
```markdown
# [TCS-Objective] {Tf} {Session} Chart Analysis
## 1. 资产合规与状态快照
- **当前资产**: [Asset Name]
- **系统执行状态**: [正常推进 / 触发现场断路器 / 降级运行]


## 2. 逻辑链路完整性审计
- **规则库一致性**: 校验 `invest_db.json` 符合率 $\rightarrow$ 100%
- **异常逻辑拦截**: [无异常 / 记录踩在 Score=3 边界已自动扣减概率权重]
- **物理存档验证**: [4+1 存档状态: PASS/FAIL]

## 3. 风控边界与数学期望
- **最大潜在亏损 (R)**: [定量敞口金额或点数]
- **数学期望胜率**: [系统期望值 %]
- **风控结论**: [允许执行 / 建议观望 / 拒绝高风险节点输入！]

## 4. 市场群体情绪映射
- **买卖博弈映射**: [例如: 情绪 Climax 导致 Momentum Confirmation / 机构空头套现]
- **认知偏差复盘**: [记录当前陷阱线 (Trapped Traders) 引发市场状态]

## 5. 核心执行策略摘要
- **概要**: [详细阐述多空博弈的核心战术逻辑]
- **风险与防御**: [向审计表述该笔交易核心需防范的假突破/诱导行为]

```


### 📄 模板 4: `report_social.md` <图表周期><交易日期><交易时间> 图表分析复盘

**Target**: 群体逻辑/外部复盘视图 (Behavioral Finance & Review)
- **Language**: **完全中文 **
- **Constraint**: 记录群体认知偏差与市场共振。
- **Template**:
```markdown
## 一、 市场所处阶段与结构感知
- **[资产/品种]**: <如：SSE Composite Index>
- **[当前趋势阶段]**: <如：大级别下跌中的弱势修复 / 趋势延续验证期>
- **[均线状态感知]**: 价格目前位于 <均线名称，如：EMA20> 之上/之下，整体反弹/下跌斜率较 <高/低>，波动率呈现 <收敛/放大> 状态。
- **[买卖博弈特征]**: <简述市场多空力量对比，如：买方缺乏一致进攻性，属于低动能修复>

## 二、 核心数据事实与技术指标审计
- **均线空间**：最新价格为 `<价格>` 点，`<均线名称>` 位于 `<价格>` 点，价差为 `<$\Delta \text{Price}$>` 点。价格与均线空间 <已拉开 / 未有效拉开>。
- **K线形态**：局部结构锚点（Pivot Low/High）形成于当前K线前第 `<N>` 根Bar。最近 `<N>` 根K线的实体重叠率接近 `<百分比>`，动能呈现 `<阶梯状衰竭 / 持续增强>`。
- **信号质量**：最新出现的 `<K线周期与类型>` 在系统审计中评分仅为 `<得分/总分>`，系统有效信号门槛为 `<门槛得分/总分>`。本次信号判定为 `<低质量信号 / 有效信号>`。

## 三、 交易逻辑路径与风控决策
- **[系统机制触发]**: 信号质量因子 <触发 / 未触发> 自动风险拦截，数学期望胜率修正为 `<百分比>`。
- **[潜在陷阱防御]**: 当前环境处于 `<低波动率 / 反弹尾端 / 震荡密集区>`，由于缺乏 `<强趋势实体K线 / 成交量>` 支持，盲目开仓极易落入 `<多头陷阱 / 空头陷阱 / 虚假突破>`。
- **[战术决策结论]**: **`<观望 (Wait-and-See) / 顺势轻仓介入 / 严格禁入>`**。

## 四、 后市关键转向参数观测 [关键参数]
- **上方阻力**：局部前高/压力位在 `<价格>` 附近，需警惕价格在此处形成 `<形态，如：双顶回撤>` 的风险。
- **下方支撑**：关键防守/止损位位于 `<价格>`（如：均线下方或局部前低）。
- **推演路径**：
  1. **延续路径**：后市需密切观察指数能否有效突破并收复 `<价格>` 关口。
  2. **反转路径**：若指数下行并跌破 `<价格>`，则宣告本次 `<反弹/下跌>` 结束，行情将回归 `<大级别空头/多头趋势>`。



## 🚩 最终校验项
- [ ] **模板 1** 是否为全英文 JSON/Matrix 且无自然语言？
- [ ] **模板 2** 是否包含 `[Quality Check]` 评分及 `[Audit Mode]` 声明？
- [ ] **模板 2, 3, 4** 是否全部使用专业中文？
- [ ] **[4+1 存档]** 4 份报告 + 1 `evidence_chart.png` 是否全部通过 `stat` 验证？

