@echo off
echo ============================================================================
echo   🚀 Trading Cognitive System (TCS) - Docker Deployment Tool
echo ============================================================================
echo.

:: Check if Docker is installed
docker --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Docker is not installed or not in PATH.
    echo Please install Docker Desktop and restart your terminal.
    pause
    exit /b 1
)

echo [1/3] Building TCS Agent Image...
docker build -t tcs-agent .
if %errorlevel% neq 0 (
    echo [ERROR] Docker build failed. Please check the Dockerfile.
    pause
    exit /b 1
)

echo.
echo [2/3] Cleaning up old containers...
docker rm -f tcs-runtime >nul 2>&1

echo.
echo [3/3] Launching TCS Agent Runtime...
echo ----------------------------------------------------------------------------
echo Starting the Cognitive Loop...
echo The system is now running in a fully isolated environment.
echo ----------------------------------------------------------------------------
docker run -it --name tcs-runtime tcs-agent

pause
