#!/bin/bash
# Start Xvfb (Virtual Frame Buffer) to support pywebview and Chromium
Xvfb :99 -screen 0 1400x900x24 &
export DISPLAY=:99

echo "TCS Environment Initialized. Starting Browser..."
python bin/tcs_browser.py
