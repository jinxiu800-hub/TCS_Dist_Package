@echo off
echo Starting TCS Cognitive System...
python F:\OBPA\PA\03_System\bin\tcs_automation.py
pause
