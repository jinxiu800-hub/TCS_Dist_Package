@echo off
chcp 65001 >nul

echo ============================================================================
echo   🚀 Trading Cognitive System (TCS) - Docker Deployment Tool
echo ============================================================================
echo.

:: 自动探测 Python 虚拟环境位置
set VENV_PYTHON=

if exist "venv\Scripts\python.exe" (
    set VENV_PYTHON=venv\Scripts\python.exe
)
if exist "hermes-agent\venv\Scripts\python.exe" (
    set VENV_PYTHON=hermes-agent\venv\Scripts\python.exe
)
if "%VENV_PYTHON%"=="" (
    if exist "%LOCALAPPDATA%\hermes\hermes-agent\venv\Scripts\python.exe" (
        set VENV_PYTHON=%LOCALAPPDATA%\hermes\hermes-agent\venv\Scripts\python.exe
    )
)

if "%VENV_PYTHON%"=="" (
    echo [INFO] Python virtual environment not found, skipping Playwright setup.
    echo.
    goto DOCKER_SECTION
)

echo [1/3] Configuring Playwright Environment...

:: 2. 修复 pip
"%VENV_PYTHON%" -m ensurepip --default-pip >nul 2>&1

:: 3. 安装 Playwright 依赖包
"%VENV_PYTHON%" -m pip install playwright >nul 2>&1

:: 4. 安装 Playwright 浏览器内核
"%VENV_PYTHON%" -m playwright install

echo [OK] Playwright environment configured successfully!
echo.

:DOCKER_SECTION
echo [2/3] Checking Docker Status...
:: 5. 检查 Docker 是否安装并启动
docker --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ----------------------------------------------------------------------------
    echo [ERROR] Docker is NOT running or NOT installed.
    echo ----------------------------------------------------------------------------
    echo 1. If Docker Desktop is NOT installed, please download and install it.
    echo 2. If it IS installed, please OPEN/START Docker Desktop now.
    echo 3. After Docker status turns "Green" (Running), press any key here to retry.
    echo ----------------------------------------------------------------------------
    pause
    goto DOCKER_SECTION
)

echo [3/3] Building TCS Agent Image...
docker build -t tcs-agent .
if %errorlevel% neq 0 (
    echo [ERROR] Docker build failed. Please check the Dockerfile.
    pause
    exit /b 1
)

echo.
echo Cleaning up old containers...
docker rm -f tcs-runtime >nul 2>&1

echo.
echo Launching TCS Agent Runtime...
echo ----------------------------------------------------------------------------
echo Starting the Cognitive Loop...
echo The system is now running in a fully isolated environment.
echo ----------------------------------------------------------------------------
docker run -it --name tcs-runtime tcs-agent

pause