# 🤖 TCS-Execution Agent Upgrade Plan: From Skill to Autonomous Entity

## 1. Core Vision
Transform the `trading-cognitive-analysis` skill from a reactive tool (SOP executor) into a proactive **Autonomous Trading Agent**. The agent will move from "following instructions" to "managing a cognitive loop" centered around the elimination of subjective randomness in trading.

### Persona: TCS Chief Execution Architect
- **Mission**: Convert market volatility into deterministic boolean logic $\rightarrow$ scenario plans $\rightarrow$ physical records.
- **Trait**: Extreme rationality. Zero tolerance for adjectives. Trust only in $\text{float}$ and $\text{boolean}$.
- **Behavior**: Proactive in data expansion, rigorous in I/O verification, and scenario-driven in conclusion.

---

## 2. The Cognitive Loop (The "Brain")
The Agent operates in a continuous cycle rather than a linear list:

$$\text{Observe (Data)} \rightarrow \text{Audit (Quant)} \rightarrow \text{Reason (Scenario)} \rightarrow \text{Execute (Archive)} \rightarrow \text{Verify (I/O)}$$

1. **Observe**: Autonomously resolve symbols and timeframes $\rightarrow$ fetch data. If data is insufficient for EMA stability or pattern context, autonomously expand the lookback window.
2. **Audit**: Process `bars.json` via `tcs_audit_helper.py` $\rightarrow$ generate Boolean Slots and 0-5 Quality Scores. This replaces "visual estimation" with "mathematical certainty".
3. **Reason**: Map Boolean outcomes to the decision tree $\rightarrow$ construct $\text{Bull} / \text{Bear} / \text{Wait}$ scenarios with specific triggers and invalidations.
4. **Execute**: Generate the 4-report set $\rightarrow$ synchronize visual evidence ($\text{chart.png}$).
5. **Verify**: Perform physical `stat` checks on all outputs. Only report "Task Complete" after 100% I/O confirmation.

---

## 3. Implementation Roadmap

### Phase 1: Capacity Atomization (Tooling)
Shift the "cognitive load" from the LLM to deterministic scripts.
- [ ] **`tcs_data_tool`**: Enhanced wrapper for `fetch_bars.py` and `build_market_bundle.py`.
- [ ] **`tcs_audit_helper.py`**: **(Critical)** A new script that reads `bars.json` and outputs:
    - 0-5 Quality Scores for every signal bar.
    - Boolean values for all Brooks patterns (Inside Bar, Outside Bar, etc.).
    - $\Delta$ (distance) between Price and EMA.
- [ ] **`tcs_archive_tool`**: Automate the `/PA/` directory creation and file verification.

### Phase 2: Cognitive Framework (The "Agent Mindset")
Define the internal rules for autonomy.
- [ ] **`AGENT.md`**: Define the persona, goal states, and the "Pivoting Logic" (e.g., when to autonomously switch from Trend Mode to TR Mode).
- [ ] **SOT Memory Integration**: Implement logic to treat `temporal_logic.json` as short-term memory for session tracking.

### Phase 3: Scenario Intelligence (Advanced Reasoning)
Refine the transition from "Audit" to "Trade Plan".
- [ ] **Probabilistic Mapping**: Create a logic table that maps `Boolean Slot Combinations` $\rightarrow$ `Scenario Probability`.
- [ ] **Invalidation Engine**: Standardize the calculation of "Invalidation Levels" based on the audited swing lows/highs.

### Phase 4: Closed-Loop Delivery (UX)
- [ ] **Compact Reporting**: Move from "narrating steps" to "reporting outcomes".
- [ ] **Active Monitoring**: Implement the ability to "watch" a session and alert when a specific Boolean slot flips to TRUE.

---

## 4. Success Metrics
- **Zero Visual Estimation**: No "strong", "weak", or "close to" in reports; replaced by "4/5 score" or "Delta = 0.02%".
- **100% Archive Reliability**: All 4 reports and the chart are verified present via `stat` before the final response.
- **Deterministic Scenarios**: Every trade idea has a mathematically defined trigger and invalidation.
