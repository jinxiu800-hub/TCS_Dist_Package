---
name: trading-cognitive-analysis
description: Trading Cognitive System (TCS) strict execution analysis skill, upgraded with an automated Al Brooks Price Action data engine.
version: 2.0.0 (Brooks-Engine Integrated)
---

# Trading Cognitive System (TCS) Final Execution Specification (Engine Edition)

This skill transforms the AI agent into a strict executor of the TCS decision tree, powered by a deterministic data engine. Any descriptive, emotional, metaphorical, or speculative technical analysis is strictly prohibited. All "visual" claims must be backed by `bars.json` quantitative data.

## 🎯 Core Logical Architecture
`User Input/Screenshot` $\rightarrow$ `SOT Parsing` $\rightarrow$ `Data Engine (fetch/render)` $\rightarrow$ `SOT Mapping` $\rightarrow$ `Quantitative Audit` $\rightarrow$ `Scenario Analysis` $\rightarrow$ `Physical Archiving`

## 🛠️ Standard Operating Procedure (SOP)

### Step 0: System Self-Check & Boot
- **System_Self_Check**: Verify skill mount and absolute path validation for target folders.
- **Boot-up**: Execute `check_skills` to validate PWD and SOT configurations.

### Step 1: Data Engine Initiation (Mandatory)
Before any analysis, the agent MUST materialize the market state:
- **Input Resolution**: Use `references/parsing_rules.md` to normalize symbols and timeframes.
- **Bundle Generation**: Execute `python3 scripts/build_market_bundle.py [params]`.
- **Verification**: Read `bundle.json` and verify `chart.png` exists.
- **SOT Mapping**: Read `temporal_logic.json` $\rightarrow$ Lock the `Session ID` $\rightarrow$ Map to data range.

### Step 1.5: Knowledge Mapping (Symmetry Validation)
The agent MUST index the current market state against the PriceAction Knowledge Base:
- **State Identification**: Determine the prevailing market phase (e.g., Trading Range, Bull Trend).
- **Reference Retrieval**: Execute `python3 bin/tcs_index_helper.py get [keyword]` to retrieve the deterministic reference standards for the identified state.
- **Symmetry Check**: Compare the raw `bars.json` data against the retrieved standards. Any discrepancy must be flagged as a `[Symmetry Gap]`.


### Step 2: Quantitative Logic Mapping (Boolean Slotting)
The agent must output the current decision tree Node ID and populate Boolean slots using `bars.json` data:
- **Data-Backed Facts**: Every slot must reference a specific bar index and a float value.
- *Format*: `Fact: Bar[N].Close (X) > EMA20 (Y) -> [Slot: Trend_Up] = TRUE`
- **Logic Trigger**: Branch the decision tree based on these deterministic outcomes.

### Step 3: Deterministic Process & Quantitative Audit
- **State Determination**: Governed by EMA 20 and 40-60 rules with $\Delta$ validation.
- **K-line Quality Audit (0-5 Score)**: 
    - Mandatory scoring using formulas in `references/framework.md`.
    - Format: `[Quality Check]: Body(X) + Close(Y) + Size(Z) = Total Score: N/5`
    - **Screener Rule**: If Total Score $< 3 \rightarrow$ `[WARNING]: Low Quality Signal`.
- **Pattern Recognition**: 
    - Refer to `references/framework.md` for Boolean requirements.
    - **TR State Switch**: If consolidation persists $\ge 5$ bars $\rightarrow$ `TR_State_Switch = TRUE` $\rightarrow$ Pivot to Directional Pivot Checklist.

### Step 4: Scenario-Based Analysis
Instead of a single conclusion, generate the three core paths based on `references/output_template.md`:
- **Bull Case**: Trigger $\rightarrow$ Invalidation $\rightarrow$ Targets $\rightarrow$ Risk.
- **Bear Case**: Trigger $\rightarrow$ Invalidation $\rightarrow$ Targets $\rightarrow$ Risk.
- **Wait Condition**: Reason for neutrality $\rightarrow$ Observation Zone.

### Step 5: Deterministic Physical Archiving
- **Root Path**: `../05_Logs/TCS_Snapshots/[YYYYMMDD_HHmm_Asset]/`
- **Evidence Sync**: Copy `chart.png` to the archiving directory.
- **Mandatory Output Set**:
    1. `report_machine.md`: Pure L-Chain / JSON / Boolean Slots / Raw Data (English).
    2. `report_human.md`: SOT Narrative + Quantitative Audit + Full Scenarios (中文).
    3. `report_generic.md`: Physical State + Key Levels + Core Conclusion (中文).
    4. `report_social.md`: Brief Narrative + Strategy + Risk (中文).
- **I/O Verification**: Every write must be followed by `stat` or `cat`.

### Step 5.5: Case Indexing (Knowledge Base Contribution)
To improve the system's recursive learning, the agent must index the outcome:
- **Case Synthesis**: Extract the core setup, reference standard, and the specific outcome (Symmetry Success/Failure).
- **Indexing**: Execute `python3 bin/tcs_index_helper.py index '[json_data]'` to archive the case into `PriceAction/docs/mes-recap/`.
- **Feedback Loop**: Note if this case confirms or contradicts the existing reference standards for future audits.


## ✍️ Illegal Terms
- ❌ **Adjectives**: Extremely strong, rapid, excellent, amazing, significant.
- ❌ **Pseudo-Technical Jargon**: Quantization, atomization, closed-loop, solidification, upgrade, evolution.
- ❌ **Sycophantic Words**: Perfect, professionals, assistant, soul, promise.

## 🚩 Pre-Output Check
- [ ] Is the analysis based on `bars.json` instead of visual estimation?
- [ ] Does the report include the 0-5 Quality Audit using the exact format?
- [ ] Does the output provide Bull/Bear/Wait scenarios with clear invalidation?
- [ ] Are all 4 reports exported to the `/PA/` segment path?
- [ ] Has `TR_State_Switch` been evaluated for consolidations $\ge 5$ bars?
- [ ] Did the Agent verify file writes with `stat`/`cat`?
