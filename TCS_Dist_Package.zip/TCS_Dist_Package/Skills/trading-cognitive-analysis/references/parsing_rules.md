# Input Parsing & Symbol Normalization

This document defines how to map user requests to the `fetch_bars.py` and `build_market_bundle.py` parameters.

## 1. Symbol Resolution
- **Explicit Prefixes**: `BINANCE:BTCUSDT.P` $\rightarrow$ `--symbol BINANCE:BTCUSDT.P --market CRYPTO`
- **Generic Crypto**: `BTC`, `BTCUSDT`, `ETH` $\rightarrow$ Default to `BINANCE:BTCUSDT.P` (Perpetuals) unless specified otherwise.
- **Stock/Index**: `S&P500`, `NDX` $\rightarrow$ Map to `^GSPC`, `^NDX` via `INDEX_ALIASES`.
- **Regional Stocks**: 
    - `600519` $\rightarrow$ `SHSE:600519` (if market=CN)
    - `700` $\rightarrow$ `HKEX:700` (if market=HK)

## 2. Temporal Window Mapping
- **Recent Relative**:
    - `最近半小时` $\rightarrow$ `--recent 30m`
    - `最近两小时` $\rightarrow$ `--recent 2h`
    - `最近一天` $\rightarrow$ `--recent 1d`
- **SOT Integration**:
    - If a `Session ID` is provided $\rightarrow$ Read `temporal_logic.json` $\rightarrow$ Extract `start_time` and `end_time` $\rightarrow$ Pass to `--start` and `--end`.

## 3. Timeframe Normalization
- `5分钟线` $\rightarrow$ `5m`
- `1小时线` $\rightarrow$ `1h`
- `日线` $\rightarrow$ `1d`

## 4. Screenshot Protocol
When a screenshot is provided:
1. **Scan for**: Ticker symbol, Timeframe label (e.g., "5m" in the top left), Date/Time axis.
2. **Slightly Expand**: Fetch data for a window $\approx 20\%$ wider than the visible segment to ensure EMA stability and context.
3. **Verify**: Compare the script-fetched data against the visual spikes in the screenshot.
