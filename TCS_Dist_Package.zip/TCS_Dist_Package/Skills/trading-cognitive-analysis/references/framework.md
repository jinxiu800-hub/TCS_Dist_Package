# Brooks Price Action Framework for TCS

This document defines the quantitative requirements for pattern confirmation. A pattern is ONLY confirmed when all associated Boolean slots evaluate to TRUE based on the `bars.json` data.

## 1. Bar Quality Metrics (The 0-5 Score)
Every signal bar must be evaluated using the following formulas:

- **Body Ratio (BR)**: `abs(Close - Open) / (High - Low)`
    - $\ge 0.8 \rightarrow 2\text{ pts}$
    - $0.5 \text{ to } 0.8 \rightarrow 1\text{ pt}$
    - $< 0.5 \rightarrow 0\text{ pts}$
- **Close Position (CP)**: `abs(Close - Extreme) / (High - Low)` (where Extreme is High for bull, Low for bear)
    - $\le 0.1 \rightarrow 2\text{ pts}$
    - $0.1 \text{ to } 0.25 \rightarrow 1\text{ pt}$
    - $> 0.25 \rightarrow 0\text{ pts}$
- **Relative Size (RS)**: `(High - Low) / avg(Range of prev 10 bars)`
    - $\ge 1.5 \times \rightarrow 1\text{ pt}$
    - $< 1.5 \times \rightarrow 0\text{ pts}$

**Total Score Calculation**: `BR + CP + RS = N/5`
- **Warning**: If Total Score $< 3 \rightarrow$ `[WARNING]: Low Quality Signal`.

## 2. Core Pattern Booleans

### 2.1 Inside Bar (IB)
- `Fact 1`: `Bar[0].High <= Bar[-1].High` $\rightarrow$ `[Slot: IB_High_Engulf] = TRUE`
- `Fact 2`: `Bar[0].Low >= Bar[-1].Low` $\rightarrow$ `[Slot: IB_Low_Engulf] = TRUE`
- **Trigger**: `IB_High_Engulf && IB_Low_Engulf`

### 2.2 Outside Bar (OB)
- `Fact 1`: `Bar[0].High > Bar[-1].High` $\rightarrow$ `[Slot: OB_High_Break] = TRUE`
- `Fact 2`: `Bar[0].Low < Bar[-1].Low` $\rightarrow$ `[Slot: OB_Low_Break] = TRUE`
- **Trigger**: `OB_High_Break && OB_Low_Break`

### 2.3 Trading Range (TR) State Switch
- **Duration Trigger**: If consolidation (Triangle/Wedge/TTR) persists for $\ge 5$ bars $\rightarrow$ `TR_State_Switch = TRUE`.
- **Directional Pivot Checklist (When TR is TRUE)**:
    - `Low_Elevated`: `Bar[0].Low > Bar[-1].Low`
    - `High_Elevated`: `Bar[0].High > Bar[-1].High`
    - **Bull Breakout**: `Low_Elevated && High_Elevated`
    - **Bear Breakout**: `!Low_Elevated && !High_Elevated`

## 3. Market Cycle Context
- **Bull Trend**: Series of Higher Highs and Higher Lows.
- **Bear Trend**: Series of Lower Highs and Lower Lows.
- **Trading Range**: Price oscillating between two clear boundaries.
- **Breakout**: Strong trend bar exiting a TR.
- **Reversal**: Two-legged correction or failing breakout.
