# TCS x Brooks Output Specification

All reports must be generated from the deterministic `SOT` path. Adjectives are strictly forbidden.

## 1. Deterministic Audit Section (The "What")
Every report must start with the quantitative state:
- **SOT Snapshot**: `{Tf} | {Session ID} | {Normalized Symbol}`
- **Data Range**: `Start: [ISO] $\rightarrow$ End: [ISO]`
- **State Summary**: `Close: X | EMA20: Y | EMA50: Z | Delta: W`
- **Signal Audit**:
    - `Bar[N]: [Pattern] -> [Quality Score N/5] -> [Boolean Slots: T/T/F]`

## 2. Scenario-Based Analysis (The "How")
Only applicable to `report_human.md` and `report_social.md`.

### 🟢 Bull Case (Long)
- **Condition**: [Specific Price Action Trigger, e.g., Break of Bar X High]
- **Invalidation**: [Specific Level, e.g., Close below EMA 20]
- **Targets**:
    - Target 1: [Price/Level]
    - Stretch Target: [Price/Level]
- **Risk**: [Quantitative R:R ratio]

### 🔴 Bear Case (Short)
- **Condition**: [Specific Price Action Trigger, e.g., Break of Bar X Low]
- **Invalidation**: [Specific Level, e.g., Close above Bar Y High]
- **Targets**:
    - Target 1: [Price/Level]
    - Stretch Target: [Price/Level]
- **Risk**: [Quantitative R:R ratio]

### 🟡 Wait Condition (Neutral)
- **Reason**: [e.g., Deep in TR, Lack of follow-through, Low Quality Signal < 3]
- **Observation Zone**: [Price Range to monitor for trigger]

## 3. Report Mapping

| Report File | Content focus | Language |
| :--- | :--- | :--- |
| `report_machine.md` | Pure L-Chain / JSON / Boolean Slots / Raw Data | English |
| `report_human.md` | SOT Narrative + Quantitative Audit + Full Scenarios | 中文 |
| `report_generic.md` | Physical State + Key Levels + Core Conclusion | 中文 |
| `report_social.md` | Brief Narrative + Strategy + Risk (High-level) | 中文 |
