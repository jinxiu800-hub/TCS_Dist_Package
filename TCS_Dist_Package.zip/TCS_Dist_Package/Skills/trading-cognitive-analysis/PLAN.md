# Upgrade Plan: Trading Cognitive Analysis (TCS) $\rightarrow$ Brooks Engine Integration

## 1. Objective
Transform the `trading-cognitive-analysis` skill from a "Manual Visual Audit" tool into a "Data-Driven Execution" system by integrating the Al Brooks automated data engine.

## 2. Mapping: Current Logic $\rightarrow$ Brooks Engine

| Current Manual Step | Brooks Engine Replacement | Expected Outcome |
| :--- | :--- | :--- |
| Visual extraction of OHLCV | `fetch_bars.py` $\rightarrow$ `bars.json` | 100% precision in price/time data. |
| Manual $\Delta$ calculation (Price vs EMA) | Pandas EMA calculations in `fetch_bars.py` | Quantitative, verifiable EMA distance. |
| Manual K-line Quality Score (0-5) | Automated $\text{Body Ratio} / \text{Wick Position}$ | Standardized, non-subjective signal quality. |
| "Visual Illusion" check | Data-backed Boolean Slotting | Patterns are confirmed by floats, not "eyes". |
| User-provided charts | `build_market_bundle.py` $\rightarrow$ `chart.png` | Agent generates the analysis chart. |
| Deterministic Report | Report + Scenario-based Trade Plan | Adds actionable trading intelligence to the audit. |

## 3. New Structure Implementation

### A. `SKILL.md` (The Orchestrator)
- Redefine the SOP to: `Fetch Data` $\rightarrow$ `Generate Chart` $\rightarrow$ `SOT Mapping` $\rightarrow$ `Quantitative Audit` $\rightarrow$ `Scenario Analysis` $\rightarrow$ `Archiving`.
- Update "Hard Rules" to forbid visual estimation where data exists.

### B. `references/` (The Knowledge Base)
- `framework.md`: Formalize the Brooks Price Action patterns into boolean logic tables.
- `output_template.md`: Integrate the 4-report system with the new Scenario-based layout.
- `SOT_mapping.md`: Define how `temporal_logic.json` maps to the script's `--start/--end` parameters.

### C. `scripts/` (The Engine)
- Port/Adapt `fetch_bars.py` and `build_market_bundle.py` to the TCS environment.
- Add a `tcs_audit_helper.py` to automate the "0-5 Score" and "Boolean Slotting" calculations.

## 4. Success Criteria
- [ ] Agent can successfully fetch data for a given Session ID without user manual input of OHLCV.
- [ ] Signal quality scores are calculated via script and match the `[Quality Check]` format.
- [ ] Reports include both the Deterministic Audit AND a Scenario-based plan.
- [ ] All 4 reports are archived with verified I/O.
