#!/usr/bin/env python3
"""
TCS Audit Helper: Quantizes Price Action into Boolean Slots and Quality Scores.
This script removes visual subjectiveness from the audit process.
"""

import json
import sys
from pathlib import Path
from typing import Any, Dict, List

def calculate_quality_score(bar: Dict[str, Any], prev_bars: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Calculates the 0-5 quality score for a signal bar."""
    high = bar["high"]
    low = bar["low"]
    open_p = bar["open"]
    close_p = bar["close"]
    total_range = high - low

    if total_range == 0:
        return {"score": 0, "br": 0, "cp": 0, "rs": 0}

    # 1. Body Ratio (BR)
    body_abs = abs(close_p - open_p)
    br = body_abs / total_range
    br_score = 2 if br >= 0.8 else (1 if br >= 0.5 else 0)

    # 2. Close Position (CP)
    # For bull: extreme is high. For bear: extreme is low.
    extreme = high if close_p >= open_p else low
    cp = abs(close_p - extreme) / total_range
    cp_score = 2 if cp <= 0.1 else (1 if cp <= 0.25 else 0)

    # 3. Relative Size (RS)
    if not prev_bars:
        rs_score = 0
    else:
        prev_ranges = [b["high"] - b["low"] for b in prev_bars]
        avg_range = sum(prev_ranges) / len(prev_ranges)
        rs = total_range / avg_range if avg_range > 0 else 0
        rs_score = 1 if rs >= 1.5 else 0

    return {
        "score": br_score + cp_score + rs_score,
        "br": round(br, 4),
        "cp": round(cp, 4),
        "rs": round(rs, 4)
    }

def detect_patterns(current: Dict[str, Any], previous: Dict[str, Any]) -> Dict[str, bool]:
    """Detects basic Brooks patterns via boolean logic."""
    patterns = {}

    # Inside Bar (IB)
    patterns["IB_High_Engulf"] = current["high"] <= previous["high"]
    patterns["IB_Low_Engulf"] = current["low"] >= previous["low"]
    patterns["IS_INSIDE_BAR"] = patterns["IB_High_Engulf"] and patterns["IB_Low_Engulf"]

    # Outside Bar (OB)
    patterns["OB_High_Break"] = current["high"] > previous["high"]
    patterns["OB_Low_Break"] = current["low"] < previous["low"]
    patterns["IS_OUTSIDE_BAR"] = patterns["OB_High_Break"] and patterns["OB_Low_Break"]

    return patterns

def analyze_bars(bars_file: Path) -> List[Dict[str, Any]]:
    """Processes bars.json and returns an audit trail."""
    if not bars_file.exists():
        raise FileNotFoundError(f"bars.json not found at {bars_file}")

    with open(bars_file, 'r') as f:
        data = json.load(f)

    # The structure of bars.json from fetch_bars.py is: {"input": ..., "summary": ..., "bars": [...]}
    bars = data.get("bars", [])
    audit_trail = []

    for i in range(len(bars)):
        bar = bars[i]
        prev_bars = bars[max(0, i-10):i]
        previous_bar = bars[i-1] if i > 0 else None

        # Quality Score
        quality = calculate_quality_score(bar, prev_bars)

        # Patterns
        patterns = {}
        if previous_bar:
            patterns = detect_patterns(bar, previous_bar)

        # EMA Distance
        # We assume ema_20 and ema_50 are already computed in bars.json
        ema20 = bar.get("ema_20")
        dist_ema20 = 0.0
        if ema20 is not None:
            dist_ema20 = (bar["close"] - ema20) / ema20

        audit_trail.append({
            "index": i,
            "timestamp": bar["timestamp"],
            "close": bar["close"],
            "quality": quality,
            "patterns": patterns,
            "ema20_delta": round(dist_ema20, 6)
        })

    return audit_trail

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to bars.json")
    parser.add_argument("--output", help="Optional output path for audit.json")
    args = parser.parse_args()

    try:
        results = analyze_bars(Path(args.input))
        output_json = json.dumps(results, indent=2)

        if args.output:
            Path(args.output).write_text(output_json)
        else:
            sys.stdout.write(output_json + "\n")

    except Exception as e:
        sys.stderr.write(f"Audit Error: {str(e)}\n")
        sys.exit(1)

if __name__ == "__main__":
    main()
