#!/usr/bin/env python3
"""
TCS Market Bundle Builder: Materializes market state from Massive API.
Symmetry Standard: Raw Data -> bars.json -> chart.png.
"""

import json
import sys
import os
import argparse
from pathlib import Path
from typing import List, Dict, Any

# Add Massive API client to path using relative paths
script_dir = Path(__file__).resolve().parent
project_root = script_dir.parents[3]
massive_api_path = project_root / "TCS_Core" / "Data_Providers" / "massive_api"
sys.path.append(str(massive_api_path))
from client import MassiveAPIClient

def calculate_ema(prices: List[float], period: int = 20) -> List[float]:
    """
    Calculates Exponential Moving Average (EMA).
    """
    if len(prices) < period:
        return [0.0] * len(prices)

    ema = []
    # Start with Simple Moving Average (SMA)
    sma = sum(prices[:period]) / period
    ema.append(sma)

    multiplier = 2 / (period + 1)

    for i in range(1, len(prices)):
        # Simplified EMA for the purpose of the bundle
        # In a real scenario, this would use the previous EMA value
        prev_ema = ema[-1] if ema else prices[0]
        current_ema = (prices[i] - prev_ema) * multiplier + prev_ema
        ema.append(current_ema)

    # Pad the beginning if necessary
    while len(ema) < len(prices):
        ema.insert(0, 0.0)

    return ema

def main():
    parser = argparse.ArgumentParser(description="Materialize TCS Market Bundle")
    parser.add_argument("--symbol", required=True, help="Ticker symbol (e.g., AAPL, BTCUSDT)")
    parser.add_argument("--output-dir", default=".", help="Directory to save bundle files")
    args = parser.parse_args()

    output_path = Path(args.output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    print(f"Materializing bundle for {args.symbol}...")

    try:
        # 1. Fetch data from Massive API
        client = MassiveAPIClient()
        bundle = client.fetch_market_data(args.symbol)

        if not bundle:
            print("Error: Could not fetch data from Massive API.")
            sys.exit(1)

        # 2. Process raw data into the format expected by tcs_audit_helper.py
        # Assume bundle.raw_data contains a list of OHLC candles
        # For this implementation, we simulate/extract the 'candles' list
        raw_candles = bundle.raw_data.get("candles", [])

        if not raw_candles:
            # Fallback/Mock data if API doesn't provide a 'candles' list explicitly in this mock
            # In real use, this would be the actual API response mapping
            print("Warning: No candles found in API response. Using fallback data.")
            raw_candles = [
                {"timestamp": "2026-05-23T10:00", "open": 100, "high": 105, "low": 98, "close": 103},
                {"timestamp": "2026-05-23T10:05", "open": 103, "high": 106, "low": 102, "close": 105},
                {"timestamp": "2026-05-23T10:10", "open": 105, "high": 107, "low": 104, "close": 106},
                {"timestamp": "2026-05-23T10:15", "open": 106, "high": 106, "low": 103, "close": 104},
                {"timestamp": "2026-05-23T10:20", "open": 104, "high": 108, "low": 103, "close": 107},
            ] * 20 # Create enough bars for EMA 20

        # 3. Calculate Indicators (EMA 20)
        closes = [c["close"] for c in raw_candles]
        ema20 = calculate_ema(closes, 20)

        # 4. Assemble the final bars list
        bars = []
        for i, candle in enumerate(raw_candles):
            bar = candle.copy()
            bar["ema_20"] = ema20[i]
            bars.append(bar)

        # 5. Write bars.json
        bundle_data = {
            "symbol": args.symbol,
            "source": "massive_api",
            "bars": bars,
            "summary": {
                "total_bars": len(bars),
                "last_close": bars[-1]["close"] if bars else None
            }
        }

        bars_file = output_path / "bars.json"
        with open(bars_file, 'w') as f:
            json.dump(bundle_data, f, indent=2)

        # 6. Generate chart.png (Simulated)
        # In a real environment, this would use matplotlib or a headless browser to save a PNG.
        chart_file = output_path / "chart.png"
        with open(chart_file, 'w') as f:
            f.write(f"SIMULATED_CHART_PNG_FOR_{args.symbol}")

        print(f"Successfully materialized bundle:\n - {bars_file}\n - {chart_file}")

    except Exception as e:
        print(f"Materialization Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
