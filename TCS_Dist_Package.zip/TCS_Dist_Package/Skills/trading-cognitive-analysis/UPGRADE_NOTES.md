# 🚀 TCS Trading Cognitive Analysis Upgrade Specification
## Version: 2.0.0 (Brooks-Engine Integrated)

## 1. Overview
This document specifies the architectural and logical transition of the `trading-cognitive-analysis` skill from a **Visual Audit System** to a **Data-Driven Execution Engine**. 

The core objective is to eliminate "Visual Illusion" and "Subjective Estimation" by integrating the Al Brooks Price Action quantitative engine while maintaining the strict deterministic archiving standards of the original TCS.

---

## 2. Major Paradigm Shift: Before vs. After

| Dimension | v1.14 (Legacy) | v2.0.0 (Engine Edition) | Logic Change |
| :--- | :--- | :--- | :--- |
| **Data Input** | User Screenshot $\rightarrow$ Visual Scan | $\text{SOT} \rightarrow \text{Scripts} \rightarrow \text{bars.json}$ | From Pixels to Floats |
| **EMA Analysis** | Visual distance estimation | Quantitative $\Delta$ calculation via Pandas | Absolute Precision |
| **Signal Audit** | Adjective-based ("Strong/Weak") | Quantitative 0-5 Scoring System | Mathematical Validation |
| **Pattern Match** | Visual pattern recognition | Boolean Slotting based on OHLCV | Deterministic Verification |
| **Conclusion** | Deterministic "Correct/Wrong" | Scenario-based "Bull/Bear/Wait" | Probability-based Planning |
| **Visualization** | User-provided image | Agent-generated `chart.png` | Closed-loop Evidence |

---

## 3. New Architectural Components

### A. The Data Engine (`/scripts`)
- **`fetch_bars.py`**: Replaces visual scanning. Fetches raw OHLCV and computes EMA(20, 50, 200) with a warm-up delta to ensure mathematical accuracy.
- **`build_market_bundle.py`**: Automates the creation of a "Market Bundle" (JSON data + PNG Chart), providing the Agent with a synchronized source of truth.

### B. The Quantitative Framework (`/references/framework.md`)
- **0-5 Quality Score**: A mandatory scoring system based on `Body Ratio`, `Close Position`, and `Relative Size`.
- **Boolean Pattern Slots**: Patterns (Inside Bar, Outside Bar, etc.) are now defined as sets of Boolean conditions that must all be `TRUE` to be confirmed.
- **TR State Switch**: Automatic pivot to "Trading Range" mode when consolidation persists $\ge 5$ bars.

### C. The Scenario-Based Output (`/references/output_template.md`)
Analysis now concludes with three distinct actionable paths:
1. **Bull Case**: $\text{Trigger} \rightarrow \text{Invalidation} \rightarrow \text{Targets} \rightarrow \text{Risk}$.
2. **Bear Case**: $\text{Trigger} \rightarrow \text{Invalidation} \rightarrow \text{Targets} \rightarrow \text{Risk}$.
3. **Wait Condition**: Neutral reasoning and observation zone.

---

## 4. Updated Standard Operating Procedure (SOP)

1. **Initialization**: Mount skill $\rightarrow$ Verify paths $\rightarrow$ Boot `check_skills`.
2. **Data Materialization**: Resolve symbol $\rightarrow$ Run `build_market_bundle.py` $\rightarrow$ Read `bundle.json`.
3. **SOT Mapping**: Lock Session ID $\rightarrow$ Map to `temporal_logic.json` $\rightarrow$ Define data window.
4. **Quantitative Audit**:
    - Populate Boolean Slots using `bars.json`.
    - Execute 0-5 Quality Scoring for signal bars.
    - Trigger Decision Tree branches based on Boolean outcomes.
5. **Scenario Synthesis**: Generate Bull/Bear/Wait paths based on the audited state.
6. **Deterministic Archiving**: Export 4 reports $\rightarrow$ Sync `chart.png` $\rightarrow$ `stat`/`cat` verification.

---

## 5. Preserved TCS Constraints (The "Hard Rules")
The following legacy constraints remain **strictly active** and mandatory:
- ❌ **Illegal Terms**: Zero tolerance for adjectives and pseudo-technical jargon.
- ❌ **Sycophancy**: No "perfect" or "professional" anthropomorphic language.
- 🛡️ **Physical Archiving**: Reports must be written to the `/PA/` segment with mandatory I/O verification.
- 🛡️ **SOT Integrity**: Timeframe and Session ID must be 1:1 consistent across all reports.
