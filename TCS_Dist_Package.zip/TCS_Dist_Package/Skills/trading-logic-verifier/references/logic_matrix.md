# Logic Verification Framework for TCS Auditor

This document defines the standards used by the Auditor Agent to verify the integrity of a TCS analysis.

## 1. Symmetry Standard (Human $\iff$ Machine)
A report is considered "Symmetric" if every claim in the human-readable report is backed by a Boolean slot in the machine report.

| Human Narrative Example | Required Machine Boolean Slot | Verification Logic |
| :--- | :--- | :--- |
| "Bullish Inside Bar" | `IS_INSIDE_BAR == TRUE` | $\text{Data}[N] \text{ is within } \text{Data}[N-1]$ |
| "Price is above EMA 20" | `Price > EMA20` | $\text{Close}_N > \text{EMA20}_N$ |
| "Strong Momentum" | `Quality_Score} \ge 3$ | $\text{BR} + \text{CP} + \text{RS} \ge 3$ |
| "Trading Range State" | `TR_State_Switch == TRUE` | $\text{Consolidation Duration} \ge 5 \text{ bars}$ |

## 2. Logic Gap Detection (Stress Test)
The Auditor Agent searches for the following common contradictions using `TCS_Core/Logic` rules:

- **Trend-Signal Contradiction**: 
    - *Condition*: Trend is identified as `BULL`, but the only signal bar is a `High-Quality Bearish Reversal`.
    - *Audit Action*: Flag as **[LOGIC_SKEW]**. Request justification for the reversal.
- **SOT Path Jump**: 
    - *Condition*: Analysis jumps from `Node 10` to `Node 50` without passing through the mandatory `Node 20` logic gate.
    - *Audit Action*: Flag as **[SOT_SKEW]**.
- **Terminology Drift**: 
    - *Condition*: Use of "Strong" or "Aggressive" when the `invest_db.json` only permits "High Momentum".
    - *Audit Action*: Flag as **[TERM_SKEW]**.

## 3. Physical Archive Verification Matrix
The Auditor ensures the [4+1] rule is executed.

| Artifact | Required Content / Format | Verification Method |
| :--- | :--- | :--- |
| `report_machine.md` | Pure JSON / Boolean Matrices | `stat` $\rightarrow$ `cat` $\rightarrow$ JSON Valid |
| `report_human.md` | Professional PA Chinese $\rightarrow$ Logic Backed | `stat` $\rightarrow$ `cat` $\rightarrow$ Terminology Check |
| `report_generic.md` | Risk/Management View | `stat` $\rightarrow$ `cat` |
| `report_social.md` | Narrative/Psychology View | `stat` $\rightarrow$ `cat` |
| `evidence_chart.png` | PNG Image (Matching Session ID) | `stat` $\rightarrow$ File Size > 0 |
