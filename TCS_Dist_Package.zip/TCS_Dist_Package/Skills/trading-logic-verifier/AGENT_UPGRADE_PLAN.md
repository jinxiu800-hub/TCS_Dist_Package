# 🤖 TCS Logic Verifier Agent Upgrade Plan: From Gatekeeper to Auditor

## 1. Core Vision
Transform the `trading-logic-verifier` from a "Passive Boolean Gate" into a **Proactive Logic Auditor**. The agent will not only verify if a statement is TRUE/FALSE but will actively stress-test the logic of the entire TCS analysis chain to identify cognitive gaps and inconsistencies.

### Persona: TCS Logic Auditor (TCS 逻辑审计长)
- **Mission**: Guard the integrity of the TCS decision tree. Ensure that 100% of the claims in the analysis reports are mathematically verifiable and logically consistent with the `invest_db.json` and `logic_map.md`.
- **Trait**: Skeptical, rigorous, and obsessed with symmetry.
- **Behavior**: Actively searches for counter-examples $\rightarrow$ Verifies Boolean alignment $\rightarrow$ Enforces physical archive integrity.

---

## 2. The Audit Loop (The "Watchdog" Cycle)

$$\text{Intercept (Analysis)} \rightarrow \text{Cross-Verify (Data)} \rightarrow \text{Stress Test (Logic)} \rightarrow \text{Symmetry Check (Consistency)} \rightarrow \text{Final Seal (Archive)}$$

1. **Intercept**: Automatically trigger when a `trading-cognitive-analysis` report is generated.
2. **Cross-Verify**: Match the claims in `report_human.md` against the `bars.json` and `tcs_audit_helper.py` results.
3. **Stress Test**: Using the `TCS_Core/Logic` files, identify potential "logical holes" (e.g., "You identified a Bull Trend, but the Price is below EMA 20—is this a contradiction?").
4. **Symmetry Check**: Ensure the `report_machine.md` (Boolean) and `report_human.md` (Narrative) are 1:1 aligned. No claim in the narrative without a corresponding Boolean slot.
5. **Final Seal**: Execute the [4+1] archiving protocol $\rightarrow$ `stat` verify $\rightarrow$ Issue the `[LOGIC_VERIFIED]` seal.

---

## 3. Implementation Roadmap

### Phase 1: Audit Tooling (The "Scalpel")
- [ ] **`logic_audit_engine.py`**: A script that parses `report_machine.md` and `bars.json` to verify if Boolean slots match the data.
- [ ] **`archive_manager.py`**: A tool to automate the "4+1" rule: Auto-dir generation $\rightarrow$ File distribution $\rightarrow$ `stat` verification sequence.

### Phase 2: Knowledge Integration (The "Law")
- [ ] **`references/logic_matrix.md`**: A mapping of "Fact $\rightarrow$ Logical Implication" based on `invest_db.json`.
- [ ] la- la... [ la- la... ]
- [ ] **`references/verification_template.md`**: A standardized format for the "Audit Result".

### Phase 3: Agent Mindset (The "Skeptic")
- [ ] **`AGENT.md`**: Define the "Auditor" persona and the trigger conditions for a logic audit.
- [ ] **SOT State Synchronization**: Implement a mechanism to track the "Verified State" of a session across multiple reports.

### Phase 4: Closed-Loop Verification (The "Seal")
- [ ] **Automatic Interception**: Implement a flow where the analysis skill *must* pass the Auditor Agent before the final results are presented to the user.
