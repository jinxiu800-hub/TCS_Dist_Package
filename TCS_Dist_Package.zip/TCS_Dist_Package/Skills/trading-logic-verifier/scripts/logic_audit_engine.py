#!/usr/bin/env python3
"""
TCS Logic Audit Engine: Verifies symmetry between reported claims and quantitative data.
This script acts as the 'truth-checker' for the Logic Auditor Agent.
"""

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

# Since we are in a separate skill folder, we implement a lightweight version
# of the audit logic or assume the helper is available.
# For robustness, we include the core calculation logic here.

def get_bar_metrics(bar: Dict[str, Any], prev_bars: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Calculates raw metrics needed for boolean slotting."""
    high, low, open_p, close_p = bar["high"], bar["low"], bar["open"], bar["close"]
    total_range = high - low
    if total_range == 0: return {"br": 0, "cp": 0, "rs": 0}

    body_abs = abs(close_p - open_p)
    br = body_abs / total_range

    extreme = high if close_p >= open_p else low
    cp = abs(close_p - extreme) / total_range

    rs = 0
    if prev_bars:
        avg_range = sum([b["high"] - b["low"] for b in prev_bars]) / len(prev_bars)
        rs = total_range / avg_range if avg_range > 0 else 0

    return {"br": br, "cp": cp, "rs": rs}

def verify_boolean_slot(slot_name: str, bar_index: int, bars: List[Dict[str, Any]]) -> Tuple[bool, str]:
    """Verifies if a specific boolean slot is actually TRUE based on data."""
    if bar_index < 0 or bar_index >= len(bars):
        return False, "Index Out of Bounds"

    curr = bars[bar_index]
    prev = bars[bar_index - 1] if bar_index > 0 else None

    if slot_name == "IB_High_Engulf":
        return (curr["high"] <= prev["high"], "High <= Prev High") if prev else (False, "No Prev Bar")
    if slot_name == "IB_Low_Engulf":
        return (curr["low"] >= prev["low"], "Low >= Prev Low") if prev else (False, "No Prev Bar")
    if slot_name == "IS_INSIDE_BAR":
        return (curr["high"] <= prev["high"] and curr["low"] >= prev["low"], "Symmetry Check") if prev else (False, "No Prev Bar")
    if slot_name == "OB_High_Break":
        return (curr["high"] > prev["high"], "High > Prev High") if prev else (False, "No Prev Bar")
    if slot_name == "OB_Low_Break":
        return (curr["low"] < prev["low"], "Low < Prev Low") if prev else (False, "No Prev Bar")
    if slot_name == "IS_OUTSIDE_BAR":
        return (curr["high"] > prev["high"] and curr["low"] < prev["low"], "Symmetry Check") if prev else (False, "No Prev Bar")

    return False, "Unknown Slot"

def parse_machine_report(file_path: Path) -> List[Tuple[int, str, bool]]:
    """
    Extracts claims from report_machine.md.
    Expected format: 'Bar[12]: [Slot: IB_High_Engulf] = TRUE'
    """
    claims = []
    content = file_path.read_text()
    pattern = r"Bar\[(\d+)\]:.*\[Slot:\s*([\w_]+)\]\s*=\s*(TRUE|FALSE)"
    matches = re.findall(pattern, content)
    for m in matches:
        claims.append((int(m[0]), m[1], m[2] == "TRUE"))
    return claims

def run_audit(bars_json_path: Path, machine_report_path: Path) -> Dict[str, Any]:
    """Performs the full symmetry audit."""
    with open(bars_json_path, 'r') as f:
        data = json.load(f)
    bars = data.get("bars", [])

    claims = parse_machine_report(machine_report_path)

    verified_claims = []
    discrepancies = []

    for idx, slot, claimed_val in claims:
        actual_val, reason = verify_boolean_slot(slot, idx, bars)
        if actual_val == claimed_val:
            verified_claims.append({"index": idx, "slot": slot, "val": actual_val})
        else:
            discrepancies.append({
                "index": idx,
                "slot": slot,
                "claimed": claimed_val,
                "actual": actual_val,
                "reason": reason
            })

    symmetry_score = (len(verified_claims) / len(claims) * 100) if claims else 0

    return {
        "total_claims": len(claims),
        "verified_count": len(verified_claims),
        "symmetry_score": round(symmetry_score, 2),
        "discrepancies": discrepancies,
        "status": "Symmetric" if symmetry_score == 100 else "Skewed"
    }

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--bars", required=True, help="Path to bars.json")
    parser.add_argument("--report", required=True, help="Path to report_machine.md")
    parser.add_argument("--output", help="Optional output path for audit_result.json")
    args = parser.parse_args()

    try:
        result = run_audit(Path(args.bars), Path(args.report))
        output = json.dumps(result, indent=2)
        if args.output:
            Path(args.output).write_text(output)
        else:
            sys.stdout.write(output + "\n")
    except Exception as e:
        sys.stderr.write(f"Audit Engine Error: {str(e)}\n")
        sys.exit(1)

if __name__ == "__main__":
    main()
