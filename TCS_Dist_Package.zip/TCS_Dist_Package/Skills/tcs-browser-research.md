---
name: tcs-browser-research
description: Advanced market research skill using integrated web-fetching tools to gather macro context, news, and sentiment, which is then filtered into the TCS Data Engine.
version: 1.0.0
---

# TCS Browser Research Skill

This skill provides the AI agent with a systematic methodology to use "browser-like" capabilities to enrich the quantitative data of the Trading Cognitive System (TCS).

## 🎯 Purpose
To prevent "data blindness" by gathering external catalyst information (Economic Calendars, Fed Speeches, News) and converting it into deterministic "Contextual Boolean Slots" for the analysis agent.

## 🛠️ Execution Workflow

### 1. Catalyst Identification (The Hunt)
When a logic-skew is detected or a high-volatility event is imminent:
- **Tool Use**: Use `WebSearch` and `defuddle` to scan:
    - TradingView News Feed
    - ForexFactory / Investing.com Economic Calendars
    - Official Central Bank releases
- **Constraint**: Only search for "Hard Facts" (Dates, Times, Target Numbers), not "Opinions".

### 2. Information Distillation (The Filter)
Convert web content into a **Contextual Fact Sheet**:
- **Format**: `[Event] -> [Time] -> [Expected Value] -> [Actual Value] -> [Symmetry Effect]`
- **Example**: `NFP Report -> 13:30 UTC -> 200k -> 210k -> [BULL_CATALYST = TRUE]`

### 3. Integration with TCS Data Engine
The browser research results MUST NOT bypass the quantitative audit. They must be fed back as:
- **External Context Slot**: `[External_Catalyst_Symmetry] = TRUE/FALSE`
- **Symmetry Check**: Does the `bars.json` price action reflect the `External Catalyst`? 
    - If Yes $\rightarrow$ `Symmetry Score +10%`
    - If No $\rightarrow$ `[LOGIC_SKEW]: Divergence between Narrative and Data`.

## 🚩 Guardrails
- **No Echo Chamber**: Do not use news to justify a bias; use news to verify a data-driven signal.
- **Source Hierarchy**: Official Data $\rightarrow$ Primary News $\rightarrow$ Analyst Commentary (Lowest priority).
- **Anti-Sycophancy**: Ignore any "market sentiment" descriptions (e.g., "The market is feeling bullish") unless it can be converted to a quantitative measure (e.g., "Put/Call Ratio < 0.6").
