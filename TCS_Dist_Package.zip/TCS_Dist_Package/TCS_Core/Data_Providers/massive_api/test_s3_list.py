import boto3
import yaml
from botocore.client import Config

def list_bucket_contents():
    config_path = "F:/OBPA/PA/03_System/config/massive_api.yaml"
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    s3 = boto3.client(
        's3',
        endpoint_url=config.get("endpoint_url"),
        aws_access_key_id=config.get("aws_access_key_id"),
        aws_secret_access_key=config.get("aws_secret_access_key"),
        config=Config(signature_version='s3v4')
    )

    bucket_name = config.get("bucket_name")
    print(f"Listing contents of bucket: {bucket_name}...")

    try:
        response = s3.list_objects_v2(Bucket=bucket_name)
        if 'Contents' in response:
            for obj in response['Contents']:
                print(f"Key: {obj['Key']}")
        else:
            print("Bucket is empty or no objects found.")
    except Exception as e:
        print(f"Error listing bucket: {e}")

if __name__ == "__main__":
    list_bucket_contents()
