from dataclasses import dataclass, field
from typing import List, Optional, Dict

@dataclass
class QuantSignal:
    """
    TCS Quantitative Signal structure.
    Symmetry Standard: 0-5 scoring for numerical facts.
    """
    metric_name: str
    value: float
    score: int  # 0-5 scale
    confidence: float  # 0.0 to 1.0
    timestamp: str
    metadata: Dict = field(default_factory=dict)

@dataclass
class MarketBundle:
    """
    Aggregated market data for a specific symbol.
    """
    symbol: str
    signals: List[QuantSignal]
    raw_data: Dict
    source: str = "massive_api"
    is_valid: bool = True
