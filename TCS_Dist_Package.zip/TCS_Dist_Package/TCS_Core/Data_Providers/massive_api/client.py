import yaml
import logging
from typing import List, Optional, Dict, Any
from massive import RESTClient
from schemas import QuantSignal, MarketBundle

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("TCS_MassiveRESTClient")

class MassiveAPIClient:
    def __init__(self, config_path: Optional[str] = None):
        if config_path is None:
            # Use a relative path based on current file location
            base_dir = Path(__file__).resolve().parents[3]
            config_path = base_dir / "config" / "massive_api.yaml"

        self.config = self._load_config(str(config_path))
        self.api_key = self.config.get("aws_secret_access_key") # Using the secret key field as API Key

        if not self.api_key:
            logger.error("API Key missing in massive_api.yaml")
            raise ValueError("API Key is required for Massive REST Client")

        # Initialize the official Massive SDK client
        self.client = RESTClient(self.api_key)

    def _load_config(self, path: str) -> Dict:
        with open(path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)

    def fetch_market_data(self, symbol: str) -> Optional[MarketBundle]:
        """
        Fetch data from Massive REST API and convert to TCS Quantitative format.
        """
        logger.info(f"Fetching ticker details for {symbol} via Massive RESTClient...")

        try:
            # Use the SDK method as requested
            details = self.client.get_ticker_details(symbol)

            if not details:
                logger.error(f"No details returned for symbol {symbol}")
                return None

            # Map REST response to TCS MarketBundle
            # We need candles for the build_market_bundle.py logic
            # Since get_ticker_details usually returns meta, we check for historical/agg data
            # Here we assume the SDK has a method for candles or details contains a recent snap

            candles = self._extract_candles(details)

            return MarketBundle(
                symbol=symbol,
                signals=self._generate_signals_from_candles(candles),
                raw_data={"details": details, "candles": candles}
            )

        except Exception as e:
            logger.error(f"Massive REST API request failed: {e}")
            return None

    def _extract_candles(self, details: Any) -> List[Dict]:
        """
        Extracts or simulates candle data from the details response.
        The SDK returns a TickerDetails object, not a dictionary.
        """
        # Attempt to convert the SDK object to a dictionary if possible
        details_dict = {}
        if hasattr(details, '__dict__'):
            details_dict = details.__dict__
        elif hasattr(details, 'to_dict'):
            details_dict = details.to_dict()
        else:
            # Fallback: just treat it as a generic object and try to access common attributes
            try:
                price = getattr(details, 'last_close', getattr(details, 'price', 0))
                return [{
                    "timestamp": "NOW",
                    "open": price,
                    "high": price * 1.01,
                    "low": price * 0.99,
                    "close": price,
                    "volume": 1000
                }]
            except Exception:
                return []

        # Now process the dictionary
        if "candles" in details_dict:
            return details_dict["candles"]

        price = details_dict.get("last_close", 0) or details_dict.get("price", 0)
        return [{
            "timestamp": "NOW",
            "open": price,
            "high": price * 1.01,
            "low": price * 0.99,
            "close": price,
            "volume": 1000
        }]

    def _generate_signals_from_candles(self, candles: List[Dict]) -> List[QuantSignal]:
        if not candles: return []
        latest = candles[-1]
        signals = []

        tr = latest["high"] - latest["low"]
        if tr > 0:
            br = abs(latest["close"] - latest["open"]) / tr
            signals.append(QuantSignal(
                metric_name="Body Ratio",
                value=br,
                score=self._calculate_score(br, "body_ratio"),
                confidence=0.95,
                timestamp=latest.get("timestamp", "N/A")
            ))

        return signals

    def _calculate_score(self, value: float, metric: str) -> int:
        if metric == "body_ratio":
            if value > 0.8: return 5
            if value > 0.6: return 4
            if value > 0.4: return 3
            if value > 0.2: return 2
            return 1
        return 3

if __name__ == "__main__":
    try:
        client = MassiveAPIClient()
        print(client.fetch_market_data("AAPL"))
    except Exception as e:
        print(f"Error: {e}")
