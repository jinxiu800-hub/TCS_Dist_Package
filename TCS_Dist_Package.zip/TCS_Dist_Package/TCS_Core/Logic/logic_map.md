# Trading Cognitive System - Logic Map

## ⚠️ Validation Report
- **Broken Links**: None. All `target_id` references are resolved across the three system modules.
- **Dead Loops**: 
    - `bull_structure` $\rightarrow$ `bull_structure` (Self-loop: indicates a "Wait/Re-evaluate" state)
    - `bear_structure` $\rightarrow$ `bear_structure` (Self-loop: indicates a "Wait/Re-evaluate" state)
    - `swing_mgmt` $\leftrightarrow$ `swing_two_return` (Cyclic: standard state monitoring loop)

---

## 🗺️ Logic Flow

### 1. Global Dispatcher (The New Root)
- `root` $\rightarrow$ `opening_session_root` (Opening), `mid_day_root` (Mid-day), `end_day_root` (End-of-day)

### 2. Opening Session (Morning Logic)
- `opening_session_root` $\rightarrow$ `gap_check`, `market_state`
- `gap_check` $\rightarrow$ `gap_50_test`, `market_state`
- `gap_50_test` $\rightarrow$ `reversal_root`, `market_state`
- `market_state` $\rightarrow$ `strong_trend_logic`, `range_logic`
- `strong_trend_logic` $\rightarrow$ `intent_selection`, `entry_50_pullback`, `trend_entry_root`
- `range_logic` $\rightarrow$ `intent_selection`, `root`, `reversal_root`
- `intent_selection` $\rightarrow$ `swing_env`, `scalp_env`
- `swing_env` $\rightarrow$ `swing_strong_trend`, `swing_narrow_channel`, `swing_range_warning`
- `scalp_env` $\rightarrow$ `scalp_strong_trend`, `scalp_narrow_channel`, `scalp_range`
- `swing_strong_trend` $\rightarrow$ `swing_mgmt`
- `swing_narrow_channel` $\rightarrow$ `swing_mgmt`
- `swing_range_warning` $\rightarrow$ `scalp_env`
- `scalp_strong_trend` $\rightarrow$ `scalp_profit_target`
- `scalp_narrow_channel` $\rightarrow$ `swing_env`
- `scalp_range` $\rightarrow$ `scalp_profit_target`
- `entry_50_pullback` $\rightarrow$ `swing_mgmt`
- `swing_mgmt` $\rightarrow$ `swing_two_return`
- `swing_two_return` $\rightarrow$ `swing_mgmt`, `swing_to_scalp`
- `scalp_profit_target` $\rightarrow$ `scalp_risk_mgmt`
- `scalp_risk_mgmt` $\rightarrow$ `scalp_trend_choice`
- `scalp_trend_choice` $\rightarrow$ `scalp_exit`
- `scalp_exit` $\rightarrow$ `mid_day_root` (Seamless Transition)
- `swing_to_scalp` $\rightarrow$ `mid_day_root` (Seamless Transition)
- `deadly_error` $\rightarrow$ `mid_day_root`
- `scaling_in` $\rightarrow$ `mid_day_root`

### 3. Mid-Day Session (Volatility & Structure)
- `mid_day_root` $\rightarrow$ `mid_day_activity_high`, `mid_day_activity_low`
- `mid_day_activity_high` $\rightarrow$ `mid_day_channel_check`, `mid_day_tr_check`, `mid_day_rev_check`
- `mid_day_activity_low` $\rightarrow$ `mid_day_wait_signal`, `mid_day_activity_high`
- `mid_day_wait_signal` $\rightarrow$ `mid_day_activity_high`, `end_day_root`, `mid_day_activity_low`
- `mid_day_channel_check` $\rightarrow$ `trend_entry_root`, `mid_day_tr_check`
- `mid_day_tr_check` $\rightarrow$ `scalp_range`, `mid_day_breakout_wait`
- `mid_day_breakout_wait` $\rightarrow$ `trend_entry_root`, `mid_day_rev_check`
- `mid_day_rev_check` $\rightarrow$ `mid_day_rev_depth`, `mid_day_activity_high`
- `mid_day_rev_depth` $\rightarrow$ `mtr_analysis`, `trend_entry_root`, `end_day_root`

### 4. End-of-Day Session (Exhaustion & Psychology)
- `end_day_root` $\rightarrow$ `end_day_momentum_high`, `end_day_momentum_low`
- `end_day_momentum_high` $\rightarrow$ `end_day_first_push`, `end_day_second_push`
- `end_day_first_push` $\rightarrow$ `end_day_time_lock`, `end_day_exhaustion_check`
- `end_day_second_push` $\rightarrow$ `end_day_time_lock`, `end_day_exhaustion_check`
- `end_day_exhaustion_check` $\rightarrow$ `end_day_climax_reversal`, `end_day_flat`
- `end_day_climax_reversal` $\rightarrow$ `scalp_strong_trend`, `end_day_flat`
- `end_day_time_lock` $\rightarrow$ `end_day_execution`, `end_day_emotional_check`
- `end_day_emotional_check` $\rightarrow$ `end_day_execution`, `end_day_flat`
- `end_day_execution` $\rightarrow$ `root` (Day Cycle Close)
- `end_day_flat` $\rightarrow$ `root` (Day Cycle Close)

### 5. Specialized Rules (Cross-Module)
- **Trend Entry**: `trend_entry_root` $\rightarrow$ `bull_structure`/`bear_structure` $\rightarrow$ `execution` $\rightarrow$ `bull_target`/`bear_target` $\rightarrow$ `trend_entry_root`
- **Reversal/MTR**: `reversal_root` $\rightarrow$ `mtr_analysis` $\rightarrow$ `mtr_target` $\rightarrow$ `reversal_mgmt` $\rightarrow$ `mid_day_root`
