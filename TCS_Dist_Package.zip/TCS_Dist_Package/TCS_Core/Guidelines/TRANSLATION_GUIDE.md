# 价格行为学英中翻译与术语一致性指南 (TRANSLATION_GUIDE.md)

本指南旨在解决 Al Brooks 价格行为学中高度专业化的术语在英中互译过程中可能出现的语义丢失、翻译不统一或误导性解读问题。

---

## 1. 翻译核心原则 (Core Translation Principles)

### 🎯 精度优先 (Precision Over Fluency)
- **原则**：专业术语的“准确性”高于“语言流畅度”。
- **要求**：严禁将专业术语进行“文学化”或“通用化”翻译。例如，将 "Squeeze" 简单翻译为 "挤压" 而不解释其在 PA 中代表的“波动率极低、即将爆发”的含义。

### 🌐 双语标注法 (Dual-Language Notation)
- **标准格式**：`中文术语 (English Term)`。
- **适用场景**：
    - 首次出现核心概念时。
    - 涉及具体信号、形态或量化指标时。
    - 在 `invest_db.json` 的 `text` 字段中，关键路径必须保留英文原词，以方便交易者对照原版教材。
- **示例**：
    - $\text{❌ 错误}$：主趋势反转
    - $\text{✅ 正确}$：主趋势反转 (Major Trend Reversal / MTR)

---

## 2. 术语翻译矩阵 (Terminology Matrix)

为确保全库一致性，必须严格遵守以下映射关系：

| 英文原词 | 推荐中文译名 | 禁忌翻译 (Avoid) | 备注 |
| :--- | :--- | :--- | :--- |
| **Bar** | K线 / 柱 | 条, 棒 | 统一使用 "K线" |
| **Swing** | 波段 / 摆动 | 波动, 摇摆 | 指一段有方向的移动 |
| **Squeeze** | 挤压 (波动率极低) | 压榨, 挤压 | 强调波动率极小 $\rightarrow$ 突破前兆 |
| **Measured Move** | 测算移动 / 等幅移动 | 衡量移动 | 基于突破幅度的 1:1 或 2:1 预测 |
| **Gap Bar** | 缺口 K 线 | 跳空K线 | 指最高/最低价不重叠的 K 线 |
| **Climax** | 高潮 (抛售/抢购) | 顶峰, 极点 | 指极端的加速运动 |
| **Two-Legged** | 两段式 | 两个腿的 | 描述回调或趋势的结构层级 |
| **Bar Counting** | 数 K 线 | 柱状计数 | 具体的 H1/H2, L1/L2 计数法 |

---

## 3. 语境感知翻译 (Context-Aware Translation)

同一词汇在不同语境下必须采取不同的翻译策略：

- **"Trend"**: 
    - 在描述长期方向时 $\rightarrow$ **趋势**。
    - 在描述短期波段时 $\rightarrow$ **倾向/动能**。
- **"Reversal"**:
    - 当持续 3-10 根 K 线 $\rightarrow$ **小反转 (Minor Reversal)**。
    - 当引发新趋势方向时 $\rightarrow$ **大反转 (Major Reversal)**。
- **"Pressure"**:
    - 涉及 Buying/Selling Pressure $\rightarrow$ **买压 / 卖压** (而非“压力”)。

---

## 4. 翻译质检流程 (Translation QA)

在将内容写入 `invest_db.json` 前，必须进行以下自检：

1. **一致性检查**：该术语在之前的 1-48 章中是如何翻译的？是否与 `DB_CONSISTENCY_GUIDE.md` 冲突？
2. **歧义排除**：如果一个中文词汇可能产生两种理解，必须在括号中标注英文原词。
3. **量化保留**：所有涉及数字、比例、百分比的表述必须原样保留，不得在翻译时进行近似处理。
4. **逻辑链条校验**：翻译后的 `text` 是否依然能清晰地引导至 `target_id`？（翻译不能破坏逻辑的指向性）。
