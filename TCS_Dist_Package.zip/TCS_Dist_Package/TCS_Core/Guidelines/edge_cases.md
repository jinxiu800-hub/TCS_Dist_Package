# TCS Boundary Cases & Ambiguity Resolver

This document records the logical gray areas, critical boundary decision thresholds, and common agent error scenarios encountered during the execution of the Trading Cognitive System (TCS). All records must strictly follow the structure: **[Scenario $\rightarrow$ Conflict Point $\rightarrow$ Deterministic Solution]**.

## 📂 Governing Principle
**Core Directive:** When logic enters an ambiguous zone, prioritize the **Conservative Principle** $\rightarrow$ lower probability weights $\rightarrow$ increase quantitative constraints $\rightarrow$ reject entry into high-risk nodes.

---

## 🛠️ Boundary Case Library

### 1. Trend Initiation Phase Differentiation
**Scenario**: Differentiating between "Strong Trend Opening" vs. "True Breakout".
- **Conflict Point**: Both present visually as strong trend bars, but their subsequent game-theoretic logics differ.
- **Deterministic Solution**:
    - **Strong Trend Opening**: Must satisfy $\text{Bar Count} \le 3$ and an EMA(20) slope of $\Delta \text{Angle} > 30^\circ$. The analytical focus is on verticality without pullbacks.
    - **True Breakout**: A $\text{Prior Range}$ must exist, and the breakout bar must close above/below the range boundary by a $\text{Distance} > 0.5 \text{ ATR}$.
    - **Priority**: If $\text{Bar Count} > 5$ without a distinct range breakout, classification as a "True Breakout" is strictly prohibited; unify under $\text{Trend From The Open}$.

### 2. Critical Thresholds for Bar Overlap
**Scenario**: Bar overlap lies exactly on a critical threshold like $20\%$ or $30\%$.
- **Conflict Point**: Determining whether to classify the bar as a $\text{Trend Bar}$ or a $\text{Doji/Trading Range Bar}$.
- **Deterministic Solution**:
    - **Conservative Bias Principle**: Default to the lower-level or more conservative structural classification.
    - **Execution Details**: 
        - If $\text{Overlap} \in [20\%, 30\%]$ and the $\text{Close}$ falls within the $40\%-60\%$ zone of the total $\text{Bar Range}$ $\rightarrow$ force classification to $\text{Doji}$ $\rightarrow$ trigger the $\text{Wait-and-See}$ node.
        - Classification as a $\text{Trend Bar}$ is permitted only when the $\text{Close}$ is located at the absolute $\text{Extreme End}$.

### 3. EMA(20) Touch vs. Penetration
**Scenario**: Price oscillates within a minute fraction around the EMA(20).
- **Conflict Point**: $\text{Price} \approx \text{MA20}$ ($\Delta$ is marginal), making it difficult to verify whether it constitutes $\text{Support}$ or a $\text{Breakthrough}$.
- **Deterministic Solution**:
    - **Quantitative Threshold**: Define $\text{Tolerance} = 0.1 \text{ ATR}$.
    - **Decision Logic**: 
        - If $\Delta \text{Price} < 0.1 \text{ ATR}$ $\rightarrow$ classify as $\text{Neutral/Tangled}$ state $\rightarrow$ disable all direct entry orders derived from the MA(20).
        - State updates require a $\text{Clear Close}$ (the entire body must close completely above/below the MA20) with a $\text{Distance} > 0.2 \text{ ATR}$.

### 4. Overlapping Pivot Zones
**Scenario**: A $\text{Resistance Flip}$ occurs within an extremely narrow $\text{Price Zone}$.
- **Conflict Point**: Support and resistance levels completely overlap, causing $\text{Long/Short}$ signals to coexist at the same price location.
- **Deterministic Solution**:
    - **Temporal Priority**: The chronologically later $\text{SOT Session}$ logic commands higher weight than the preceding one.
    - **Momentum Validation**: Audit the $\text{Body-to-Wick Ratio}$ of the last 3 bars. The direction displaying a $\text{Ratio} > 60\%$ inherits the $\text{Logic Override}$ authorization.

### 5. Automated I/O Execution & Physical Verification Failure Circuit Breaker
**Scenario**: The `trading-logic-verifier` executes the 4+1 automated directory generation and file write operations, but OS-level I/O latency or permissions conflict causes the `stat` validation to fail for any of the 5 required files.
- **Conflict Point**: The core skill dictates "Strictly forbid making success commitments without underlying I/O confirmation," while `report_machine.md` must be instantaneously persisted. The system risks hanging or failing silently.
- **Deterministic Solution**:
    - **Hard Circuit Breaker**: If any single file returns `FALSE` or `Null` during the `stat` check, the output of `[ARCHIVE_COMPLETE]` is strictly banned.
    - **Error Routing**: Immediately halt subsequent node routing within the Global Dispatcher, throw a `[FATAL_IO_ERROR]` to the terminal, and force-dump the current active memory buffer of `current_session_state.json` into the temporary root directory. Do not feed a success confirmation back to the SOT (`temporal_logic.json`) without confirmed underlying I/O.

### 6. Long Sequence Context Evaporation & Audit Mode Conversion
**Scenario**: User inputs a vague prompt (e.g., "Analyze today's market performance"), which simultaneously implies interest in the latest bars (Live Snapshot) and an analytical sweep of full-day historical price action.
- **Conflict Point**: The trigger conditions for Mode A (audit 3 to 5 key bars in Pivot Zones) and Mode B (force split full chart into 3 rolling segments of ~27 bars) overlap.
- **Deterministic Solution**:
    - **Downgrade Trigger Rule**: If total unclosed bars $\ge 5$ and user intent spans "historical" or "full-day" parameters, **force-disable Mode A** and unconditionally lock into **Mode B (Full-Day Review Audit)**.
    - **Step-by-Step Constraint**: Under Mode B, writing the entire day's analysis inside a single prompt generation is prohibited. Insert a hard `[CONTEXT_LOCK_WAITING]` interactive prompt at the end of the first 27-bar segment. Do not output subsequent segments until the user explicitly confirms that context has not degraded.

### 7. K-Line Quality Margin Mitigation (Score = 3)
**Scenario**: A signal bar's quantitative evaluation yields exactly a $\text{Total Score} = 3$ (e.g., Body Ratio = 1 pt, Close Position = 1 pt, Relative Size = 1 pt).
- **Conflict Point**: The score hits the technical passing baseline ($\ge 3$), but because every dimension sits right at the transitional border, it is prone to AI visual illusion and systemic over-interpretation.
- **Deterministic Solution**:
    - **Weighted Composite Audit**: When $\text{Total Score} == 3$, automatically invoke an auxiliary verification layer checking the overlap metric of preceding bars.
    - **Routing Logic**: If the overlap of the preceding 3 bars $\in [20\%, 30\%]$, then despite hitting the 3-point score, the agent **must enforce** the warning: `[WARNING]: Low Quality Signal - Reduced Probability.`, and deduct $15\%$ from the mathematical expectancy (`prob`) within `report_machine.md`.

### 8. TR_State_Switch Overdrive During Complex Pattern Horizons
**Scenario**: The market has been consolidating inside a complex Contracting Triangle (TTR) or Three Pushes Wedge, and is currently forming its 5th consecutive bar.
- **Conflict Point**: The boolean slots for geometric patterns (`Higher_Lows && Lower_Highs`) still technically evaluate to true, but the duration of the consolidation has reached the $\ge 5$ bars threshold limitation.
- **Deterministic Solution**:
    - **Temporal Short-Circuit**: The moment `Bar_Count` reaches $5$, the complex pattern classifier must execute a hard logic truncation.
    - **Forced State Downgrade**: Instantly activate `TR_State_Switch = TRUE`, wipe all active complex structural labels (Wedge, Triangle, Inside Bar), and transfer control to the **Unified Trading Range State (TR)**. Subsequent analysis must pivot entirely to the **Directional Pivot Checklist** to evaluate structural highs/lows. If mixed, lock the trading style to `Limit Orders Only`, and strip all breakout-trading terminology from `report_human.md`.

### 9. State Synchronization Mutation & Memory Locking
**Scenario**: During the exact instant the Global Dispatcher transitions states from `Market State` to `Trading Intent`, a microsecond timestamp drift occurs in the underlying data feed, or the Session ID within `temporal_logic.json` becomes unaligned.
- **Conflict Point**: The `target_node_id` emitted by the preceding module mismatches the matrix structure being written to `current_session_state.json`.
- **Deterministic Solution**:
    - **Atomic Mutex Lock**: Prior to executing any state persistence write to `current_session_state.json`, the system must invoke `SOT_State_Sync` to run a dual shadow validation.
    - **Validation Formula**: Verify that $\text{Input\_Node\_ID} == \text{Global\_Dispatcher\_Current\_ID}$. If this condition fails, lock the active slots against mutations, roll back state parameters to the previous bar's verified Physical State, and raise an interactive prompt forcing the user to manually re-verify the Session ID.

---

## 🚩 Maintenance Log
- [2026-05-22] Initialized boundary case library.
- [2026-05-22] Augmented with clauses 5–9 derived from `trading-cognitive-analysis v1.14.0` and `trading-logic-verifier v2.4.0` execution rules, solving for I/O exceptions, context audit routing anomalies, borderline K-line scoring, complex-to-TR state downgrades, and sync mutation errors.