# JSON 编辑防呆与维护规则 (JSON_EDIT_RULES.md)

为了确保 `invest_db.json` 等关键决策数据库的结构完整性，防止出现语法崩溃（如 `JSONDecodeError`），所有修改必须严格遵守以下规则。

## 1. 写入与修改原则 (Writing Principles)
- **优先全量覆盖**：在进行模块级扩展（增加 5 个以上节点）时，必须使用 `Write` 工具进行全量覆盖，严禁使用多次 `Edit` 局部替换，以避免因索引偏移或匹配失败导致的结构损坏。
- **禁止非标字符**：严禁在 JSON 键名（Key）前添加任何非标准前缀（如 `la "text"` $\rightarrow$ 必须为 `"text"`）。
- **严格遵循二元树**：确保每个 `target_id` 都有对应的节点定义，严禁出现“悬空”的 ID 引用。

## 2. 验证流程 (Validation Workflow)
- **修改前备份**：执行任何写入操作前，必须运行 `cp invest_db.json invest_db_backup_[TIMESTAMP].json`。
- **写入后校验**：每次 `Write` 或 `Edit` 完成后，必须立即通过以下方式验证语法：
  - 运行命令：`python -c "import json; json.load(open('invest_db.json', encoding='utf-8'))"`
  - 如果该命令报错，必须立即回滚到最近的备份，严禁在损坏基础上继续叠加修改。

## 3. 命名与结构约定 (Naming Conventions)
- **时段前缀**：
  - 开盘 $\rightarrow$ `opening_...`
  - 盘中 $\rightarrow$ `mid_day_...`
  - 盘末 $\rightarrow$ `end_day_...`
- **逻辑闭环**：所有末端执行节点必须指向 `root` 或对应的时段入口，确保决策链路无死路。

## 4. 错误恢复机制 (Recovery)
- 发现语法错误 $\rightarrow$ 停止所有写入 $\rightarrow$ 检查备份文件 $\rightarrow$ 执行全量恢复 $\rightarrow$ 重新尝试单点修改。
