# 交易认知数据库一致性与架构指南 (DB_CONSISTENCY_GUIDE.md)

本指南定义了 `invest_db.json` 的底层设计语言，确保系统在规模扩大后依然保持逻辑一致性、可维护性和可验证性。

---

## 1. 核心架构模型 (The Macro-Architecture)

本系统采用 **"调度-路由-执行" (Dispatch $\rightarrow$ Route $\rightarrow$ Execute)** 三层架构：

- **L1: 调度层 (Dispatcher)**: `root` 及相关时段入口。负责根据时间、波动率等宏观维度分流。
- **L2: 路由层 (Router)**: `market_state`, `intent_selection`, `mtr_analysis` 等。负责将用户引导至具体的策略分支（如：波段 $\rightarrow$ 强趋势 $\rightarrow$ 窄通道）。
- **L3: 执行层 (Executor)**: `bull_execution`, `reversal_mgmt` 等。提供具体的入场、止损、目标设定方案。

---

## 2. 节点命名规范 (Naming Convention)

为了实现“看 ID 即可知意”，所有 ID 必须遵循：`[模块]_[语义]_[序号/状态]`。

| 模块前缀 | 适用场景 | 示例 |
| :--- | :--- | :--- |
| `root` | 全局入口 | `root` |
| `opening_` | 开盘 90min 逻辑 | `opening_session_root`, `gap_check` |
| `mid_day_` | 盘中波动率/结构分析 | `mid_day_root`, `mid_day_activity_high` |
| `end_day_` | 盘末竭尽/心理过滤 | `end_day_root`, `end_day_time_lock` |
| `swing_` | 波段交易逻辑 | `swing_env`, `swing_mgmt` |
| `scalp_` | 剥头皮交易逻辑 | `scalp_env`, `scalp_exit` |
| `mtr_` | 主趋势反转专项 | `mtr_analysis`, `mtr_target` |
| `bull_` / `bear_` | 多头/空头具体执行 | `bull_structure`, `bear_target` |

---

## 3. 逻辑流转准则 (Flow Rules)

### 3.1 链路闭环 (Closed Loop)
- **禁止死端**：所有叶子节点必须通过 `target_id` 指向一个已存在或即将创建的节点。
- **回流机制**：所有执行路径的终点必须通过 `target_id` 回流至 `root` 或时段调度中心 (`mid_day_root` 等)，以允许交易者在交易结束或失效后重新开始。

### 3.2 转换优先级 (Transition Priority)
- **降级优先**：当波段交易前提失效时 $\rightarrow$ 引导至剥头皮 (`swing_to_scalp`)。
- **环境优先**：必须先确认 `market_state` (环境) $\rightarrow$ 再确定 `intent` (意图)。

---

## 4. 内容编写规范 (Content Guidelines)

### 4.1 文本表达
- **流程引导**：在 `text` 中使用 $\rightarrow$ 符号表示逻辑流向（例如: `"识别 $\rightarrow$ 确认 $\rightarrow$ 执行"`）。
- **量化优先**：尽可能使用具体数值替代模糊词汇（例如: 用 `"持续 15-20 根 K 线"` 代替 `"持续较长时间"`）。

### 4.2 选项设计
- **互斥性**：同一个节点的 `options` 应该是互斥的决策分支，而非简单的信息叠加。
- **目标导向**：每个选项必须清晰地告诉交易者“如果满足此条件，下一步该看什么”。

---

## 5. 验证基准 (Verification Baseline)

任何新加入的节点必须通过以下测试：
1. **可达性**：从 `root` 出发，是否存在一条随机路径能到达此节点？
2. **闭环性**：从该节点出发，是否能在 N 步内回到 `root` 或调度中心？
3. **唯一性**：`id` 是否与现有 40+ 个节点重复？
