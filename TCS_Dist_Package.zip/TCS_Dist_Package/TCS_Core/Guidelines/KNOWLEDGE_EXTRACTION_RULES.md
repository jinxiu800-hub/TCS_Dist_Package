# 知识提取与转化维护协议 (KNOWLEDGE_EXTRACTION_RULES.md)

**角色定义**：严谨的交易认知图谱构建专家。
**核心目标**：对历史知识节点进行“回归测试”与“差分补全”，确保从 $\text{SRT} \rightarrow \text{MD} \rightarrow \text{JSON}$ 的全链路数据纯净度、逻辑完备性及机器可读性。

## 0. 数据来源 (Data Provenance)
- **唯一原始真理源 (Source of Truth)**：数据库中所有知识节点的原始素材均来自以下路径：
  `F:\OBPA\PA\02_al_brooks_library\video_source\Al Brooks - Brooks Trading Course 2018`
- **溯源要求**：在进行回归测试或差分补全时，必须以此路径下的原始文件为准。

---

## 1. SRT $\rightarrow$ MD 文本清洗规则 (Text Cleaning)

字幕文件含有大量时间戳和碎片化行，必须在转化为 MD 前进行以下处理：

### ❌ 严禁保留项
- **时间戳与序号**：删除所有 `00:00:00,000 --> 00:00:00,000` 格式的行及每段话之前的数字序号。
- **口语化冗余**：剔除无实际语义的口语助词（如 *you know, so, okay, standard, basically* 等）。

### ✅ 格式化与排版要求
- **语义合并**：将碎片化、被截断的句子合并为完整段落，确保逻辑连贯。
- **标点规范**：
    - 叙述文本统一使用**中文全角标点**。
    - 数值、百分比、专业术语（如 **50%**, **20-bar**）前后保留西文空格或半角符号。
- **术语保留**：严格保留 Al Brooks 专有术语（如 $\text{H2}$, $\text{MTR}$, $\text{Measured Move}$），严禁模糊化翻译。
- **原意优先**：必须保证是“原意提取”而非“AI 摘要”，严禁擅自删减核心细节。
- **量化锚点强制提取**：**必须**扫描并保留所有量化数据，包括但不限于：
    - 概率百分比 (例如：$\text{90\% probability}$)
    - K 线根数 (例如：$\text{Bar 18}$)
    - 价格点数 (例如：$\text{4 points}$)
    - 时间窗口 (例如：$\text{first two hours}$)

---

## 2. Markdown 文档排版规范 (Typography & Layout)

所有存入 `docs/` 目录的 `.md` 文件必须遵循以下结构：

### 📂 文件命名与头部
- **格式**：`章节号[a-z].md` (例如 `49a.md`, `50b.md`)。
- **头部要求**：除非明确要求，否则**禁止**使用 YAML Frontmatter (即 `---` 包围的 metadata 区)，直接以 `# 标题` 或 `## 标题` 开始。

### 📑 内容层级映射
1. **标题**：使用 `# 章节号 - 标题` 格式。
2. **层级结构**：
    - `##` $\rightarrow$ 核心概念/主要逻辑 $\rightarrow$ 映射为 JSON 节点的 `"title"`。
    - `###` $\rightarrow$ 具体执行细节/条件 $\rightarrow$ 映射为 `"options"` 数组中子对象的 `"text"`。
    - `-` 或 `1.` $\rightarrow$ 细节描述/风险提示 $\rightarrow$ 映射为节点的 `"content"` 或选项的 `"description"`。
3. **视觉强调**：
    - **关键数值/条件**：使用 **粗体** (例如：**20 根 K 线**, **50% 回调**)。
    - **警示信息**：使用 `> [!WARNING]` 块或 $\text{⚠️}$ 符号标注致命错误。

---

## 3. MD $\rightarrow$ JSON 逻辑转化协议 (Logic Mapping)

在将 MD 内容写入 `invest_db.json` 时，必须遵守以下语法准则：

### 🛠️ JSON 语法强制要求
- **根结构约束**：`invest_db.json` 的根节点必须是**列表 (List)** 而非字典 (Dictionary)。禁止对根对象使用 `.get()` 等字典方法，必须通过迭代或过滤来定位节点。
- **绝对转义**：
    - 所有双引号 `"` 必须转义为 `\"`。
    - 所有反斜杠 `\\` 必须转义为 `\\\\`。
    - **换行符转义**：MD 文本中的段落换行必须严格转换为 `\\\\n`，禁止出现物理换行。
- **字符清洗**：
    - 严禁引入不规范的引号（如 `’` `”`），统一转换为标准半角 `'` 和转义后的 `\"`。
    - 禁止使用非标准 Unicode 字符或特殊表情符号，以免导致 `json.load()` 崩溃。
- **ID 唯一性**：每个新生成的 `id` 必须在全库唯一，建议采用 `模块_语义_序号` 格式（如 `mtr_execution_01`）。
- **写入机制 (Critical)**：
    - **禁止使用 `Edit` 工具直接修改 `.json` 文件**：由于 JSON 对缩进、空格和换行极其敏感，`Edit` 工具的字符串匹配极易失败且易破坏结构。
    - **强制使用 Python 脚本更新**：必须通过 `Bash` 调用 Python 脚本（`json.load` $\rightarrow$ 内存对象操作 $\rightarrow$ `json.dump`）进行结构化读写，确保数据完整性。
    - **严禁使用 `python -c` 传参**：禁止在 Bash 中使用 `python -c` 执行复杂的 JSON 更新逻辑，以避免 Shell 转义问题或权限错误。必须将逻辑写入独立的 `.py` 文件后执行。


### 🔗 链路闭环要求
- **禁止死端**：每个节点的 `target_id` 必须指向一个已存在或即将创建的节点。
- **回流机制**：所有执行路径的终点必须通过 `target_id` 回流至 `root` 或时段调度中心 (`mid_day_root` 等)。

---

## 4. 历史数据回归与补全流程 (Regression & Completion)

当对已有 `.md` 文件进行更新或审核时，必须执行以下“回归测试”工作流：

1. **Baseline 对比**：将现有 $\text{MD}$ 与原始 $\text{SRT}$ 进行逐行对比。
2. **差分识别 (Diff)**：
    - **量化缺失**：检查是否遗漏了概率、点数、K 线根数等量化锚点。
    - **逻辑模糊**：检查是否使用了概括性词汇（如“震荡一段时间”）而未指明具体逻辑依赖（如“在第一个波段形成前”）。
    - **纯净度偏差**：识别并剔除口语化引导词。
3. **非破坏性补全**：
    - 严禁随意修改原有结构或 ID。
    - 在原节点下方以追加分支 $\text{(options/content)}$ 的形式补完缺失细节。
4. **一致性验证**：确保补全后的内容在语气、标点和术语上与新规保持高度一致。

---

## 5. 质量验证流程 (QA Process)

每次更新 `invest_db.json` 后，必须依次执行以下验证步骤：

1. **Step 0: Schema 约束检查** $\rightarrow$ 运行 `check_schema.py` $\rightarrow$ 确保所有 Key 完整且数据类型合规。
2. **Step 1: 语法检查** $\rightarrow$ 运行 `json.loads()` $\rightarrow$ 确保无 `JSONDecodeError`。
3. **Step 2: 连通性验证** $\rightarrow$ 运行 `verify_reachability.py` $\rightarrow$ 确认 $\text{True Logical Orphans} == 0$。
4. **Step 3: 随机模拟** $\rightarrow$ 运行 `test_logic.py` $\rightarrow$ 确认 $\text{Reach Rate}$ 处于合理区间且无死循环。
